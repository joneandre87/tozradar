<?php
require_once '../config.php';
requireLogin();
$pageTitle = 'Tøzsniff - Settings';
include '../header.php';
?>
<main class="main-content"><div class="container"><h3>Sniffer config</h3><form>...</form><div class="back-link"><a href="/feature.php?slug=tzsniff">← Back</a></div></div></main>
<?php include '../footer.php'; ?>