<?php
require_once '../config.php';
requireLogin();
$pageTitle = 'Tøzsniff';
include '../header.php';
?>
<main class="main-content"><div class="container"><h2>TøzSniff</h2><p>Live overvåkning</p></div></main>
<?php include '../footer.php'; ?>