    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
        </div>
    </footer>

    <script src="/assets/script.js"></script>
    <?php if (isset($customJS) && $customJS): ?>
    <script><?php echo $customJS; ?></script>
    <?php endif; ?>
</body>
</html>
